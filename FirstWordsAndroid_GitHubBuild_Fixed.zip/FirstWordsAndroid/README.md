# First Words — Android app

A small offline vocabulary diary for a child. It supports English, Chinese, and Portuguese, an adjustable learning date, optional notes, language filtering, deletion, basic counts, and CSV export.

## Build an APK with GitHub Actions

The repository includes `.github/workflows/build-apk.yml`.

1. Upload the project files to a GitHub repository on its `main` branch.
2. Open the repository's **Actions** tab.
3. Select **Build First Words APK** and tap **Run workflow** if it has not started automatically.
4. Open the completed workflow run.
5. Under **Artifacts**, download `first-words-debug-apk`.
6. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone. You may need to allow your browser or file manager to install unknown apps.

The APK is a debug build, suitable for personal installation.

All entries are stored locally on the phone in app-private storage. Export CSV periodically if you want a backup; uninstalling the app normally removes its local data.
