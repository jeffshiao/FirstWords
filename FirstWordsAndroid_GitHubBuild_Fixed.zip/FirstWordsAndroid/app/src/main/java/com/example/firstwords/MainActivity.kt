package com.example.firstwords

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class WordEntry(
    val id: Long,
    val word: String,
    val language: String,
    val date: String,
    val notes: String
)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("first_words", MODE_PRIVATE) }
    private val entries = mutableListOf<WordEntry>()
    private lateinit var wordInput: EditText
    private lateinit var notesInput: EditText
    private lateinit var languageSpinner: Spinner
    private lateinit var dateButton: Button
    private lateinit var listContainer: LinearLayout
    private lateinit var statsText: TextView
    private lateinit var filterSpinner: Spinner
    private var selectedDate = today()

    private val languages = listOf("English", "中文 (Chinese)", "Português (Portuguese)")
    private val languageCodes = listOf("English", "Chinese", "Portuguese")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadEntries()
        buildScreen()
        renderEntries()
    }

    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
            setBackgroundColor(0xFFF7F8F5.toInt())
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(TextView(this).apply {
            text = "First Words"
            textSize = 28f
            setTextColor(0xFF20352D.toInt())
            typeface = Typeface.DEFAULT_BOLD
        })
        page.addView(TextView(this).apply {
            text = "A little record of the words he learns"
            textSize = 14f
            setTextColor(0xFF65736B.toInt())
            setPadding(0, dp(3), 0, dp(18))
        })

        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = rounded(0xFFFFFFFF.toInt(), 18)
        }
        page.addView(form)

        form.addView(label("Add a word"))
        wordInput = EditText(this).apply {
            hint = "e.g. apple, ball, 媽媽, água"
            textSize = 16f
            singleLine = true
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(0xFFF1F4F0.toInt(), 10)
        }
        form.addView(wordInput, matchWrap())

        form.addView(label("Language"))
        languageSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, languages)
        }
        form.addView(languageSpinner, matchWrap())

        form.addView(label("Date learned"))
        dateButton = Button(this).apply {
            text = selectedDate
            isAllCaps = false
            setOnClickListener { showDatePicker() }
        }
        form.addView(dateButton, matchWrap())

        form.addView(label("Notes (optional)"))
        notesInput = EditText(this).apply {
            hint = "How did he say it? What did he mean?"
            textSize = 15f
            minLines = 2
            maxLines = 4
            gravity = Gravity.TOP
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(0xFFF1F4F0.toInt(), 10)
        }
        form.addView(notesInput, matchWrap())

        val addButton = Button(this).apply {
            text = "Add word"
            isAllCaps = false
            setTextColor(0xFFFFFFFF.toInt())
            background = rounded(0xFF287B60.toInt(), 12)
            setOnClickListener { addEntry() }
        }
        val buttonParams = matchWrap()
        buttonParams.topMargin = dp(12)
        form.addView(addButton, buttonParams)

        statsText = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFF40534A.toInt())
            setPadding(0, dp(20), 0, dp(10))
        }
        page.addView(statsText)

        val historyHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        historyHeader.addView(TextView(this).apply {
            text = "Word history"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF20352D.toInt())
        }, LinearLayout.LayoutParams(0, -2, 1f))
        val exportButton = Button(this).apply {
            text = "Export CSV"
            isAllCaps = false
            setOnClickListener { exportCsv() }
        }
        historyHeader.addView(exportButton)
        page.addView(historyHeader)

        filterSpinner = Spinner(this).apply {
            val options = listOf("All languages") + languages
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, options)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    renderEntries()
                }
            }
        }
        page.addView(filterSpinner, matchWrap())

        listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(listContainer, matchWrap())
    }

    private fun addEntry() {
        val word = wordInput.text.toString().trim()
        if (word.isEmpty()) {
            wordInput.error = "Enter a word first"
            return
        }
        val language = languageCodes[languageSpinner.selectedItemPosition]
        entries.add(WordEntry(System.currentTimeMillis(), word, language, selectedDate, notesInput.text.toString().trim()))
        saveEntries()
        wordInput.text.clear()
        notesInput.text.clear()
        selectedDate = today()
        dateButton.text = selectedDate
        renderEntries()
        Toast.makeText(this, "Word saved", Toast.LENGTH_SHORT).show()
    }

    private fun showDatePicker() {
        val parts = selectedDate.split("-").map { it.toInt() }
        DatePickerDialog(this, { _, year, month, day ->
            selectedDate = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day)
            dateButton.text = selectedDate
        }, parts[0], parts[1] - 1, parts[2]).show()
    }

    private fun renderEntries() {
        if (!::listContainer.isInitialized) return
        listContainer.removeAllViews()
        val filter = if (filterSpinner.selectedItemPosition == 0) null
                     else languageCodes[filterSpinner.selectedItemPosition - 1]
        val visible = entries.filter { filter == null || it.language == filter }
            .sortedWith(compareByDescending<WordEntry> { it.date }.thenByDescending { it.id })

        val counts = languageCodes.associateWith { lang -> entries.count { it.language == lang } }
        statsText.text = "Total: ${entries.size} words   ·   English ${counts["English"]}  ·  中文 ${counts["Chinese"]}  ·  Português ${counts["Portuguese"]}"

        if (visible.isEmpty()) {
            listContainer.addView(TextView(this).apply {
                text = if (entries.isEmpty()) "Your son's first word will appear here." else "No words for this language yet."
                textSize = 14f
                setTextColor(0xFF758078.toInt())
                setPadding(0, dp(16), 0, dp(16))
            })
        }
        visible.forEach { entry ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = rounded(0xFFFFFFFF.toInt(), 14)
            }
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            top.addView(TextView(this).apply {
                text = entry.word
                textSize = 19f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xFF20352D.toInt())
            }, LinearLayout.LayoutParams(0, -2, 1f))
            top.addView(TextView(this).apply {
                text = entry.date
                textSize = 12f
                setTextColor(0xFF718078.toInt())
            })
            card.addView(top)
            card.addView(TextView(this).apply {
                text = languageLabel(entry.language)
                textSize = 12f
                setTextColor(0xFF287B60.toInt())
                setPadding(0, dp(4), 0, 0)
            })
            if (entry.notes.isNotBlank()) card.addView(TextView(this).apply {
                text = entry.notes
                textSize = 14f
                setTextColor(0xFF536159.toInt())
                setPadding(0, dp(7), 0, 0)
            })
            val actions = LinearLayout(this).apply { gravity = Gravity.END }
            val delete = Button(this).apply {
                text = "Delete"
                isAllCaps = false
                setOnClickListener {
                    entries.removeAll { it.id == entry.id }
                    saveEntries()
                    renderEntries()
                }
            }
            actions.addView(delete)
            card.addView(actions)
            val params = matchWrap().apply { topMargin = dp(9) }
            listContainer.addView(card, params)
        }
    }

    private fun languageLabel(code: String) = when (code) {
        "Chinese" -> "中文 · Chinese"
        "Portuguese" -> "Português · Portuguese"
        else -> "English"
    }

    private fun saveEntries() {
        val array = JSONArray()
        entries.forEach {
            array.put(JSONObject().apply {
                put("id", it.id); put("word", it.word); put("language", it.language)
                put("date", it.date); put("notes", it.notes)
            })
        }
        prefs.edit().putString("entries", array.toString()).apply()
    }

    private fun loadEntries() {
        val raw = prefs.getString("entries", "[]") ?: "[]"
        val array = JSONArray(raw)
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            entries.add(WordEntry(o.optLong("id"), o.optString("word"), o.optString("language"),
                o.optString("date"), o.optString("notes")))
        }
    }

    private fun exportCsv() {
        val header = "Word,Language,Date learned,Notes\n"
        val body = entries.sortedBy { it.date }.joinToString("\n") {
            listOf(it.word, it.language, it.date, it.notes).joinToString(",") { value ->
                "\"" + value.replace("\"", "\"\"") + "\""
            }
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "my_sons_first_words.csv")
        }
        pendingCsv = header + body
        startActivityForResult(intent, EXPORT_REQUEST)
    }

    private var pendingCsv: String = ""
    @Deprecated("Deprecated in Android but supported for this simple file picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == EXPORT_REQUEST && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(pendingCsv) }
            Toast.makeText(this, "CSV exported", Toast.LENGTH_SHORT).show()
        }
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(0xFF40534A.toInt())
        setPadding(0, dp(13), 0, dp(6))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    companion object { private const val EXPORT_REQUEST = 42 }
}
